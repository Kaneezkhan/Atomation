package kaneez;

public class project1 {

	public static void main(String[] args) throws Exception 
	{
		data1 d=new data1();

		d.run();
		d.arraymethod();
	    d.closemethod();
		
		System.out.println("end");
	}

}
